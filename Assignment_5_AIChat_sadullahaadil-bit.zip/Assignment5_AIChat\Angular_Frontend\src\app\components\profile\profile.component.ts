﻿import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  template: 
    <h2>User Profile</h2>
    <form [formGroup]="profileForm" (ngSubmit)="updateProfile()">
      <div style="margin-bottom: 10px;">
        <label>Display Name: </label>
        <input formControlName="displayName" type="text" />
      </div>
      <div style="margin-bottom: 10px;">
        <label>Preferences: </label>
        <input formControlName="preferences" type="text" />
      </div>
      <button type="submit" [disabled]="profileForm.invalid || isLoading">Save Changes</button>
    </form>
    <div *ngIf="successMsg" style="color: green; margin-top: 10px;">{{ successMsg }}</div>
  
})
export class ProfileComponent implements OnInit {
  profileForm: FormGroup;
  isLoading = false;
  successMsg = '';
  private apiUrl = 'http://localhost:5000/api/profile';

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.profileForm = this.fb.group({
      displayName: ['', Validators.required],
      preferences: ['']
    });
  }

  ngOnInit() {
    this.http.get<any>(this.apiUrl).subscribe({
      next: (data) => {
        this.profileForm.patchValue(data);
      }
    });
  }

  updateProfile() {
    if (this.profileForm.valid) {
      this.isLoading = true;
      this.successMsg = '';
      this.http.put(this.apiUrl, this.profileForm.value).subscribe({
        next: () => {
          this.successMsg = 'Profile updated successfully!';
          this.isLoading = false;
        },
        error: () => {
          this.isLoading = false;
        }
      });
    }
  }
}
