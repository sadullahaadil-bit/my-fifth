import os

def create_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

# ==========================================
# 1. .NET CORE BACKEND FILES
# ==========================================
dotnet_dir = r"C:\Users\sadul\.gemini\antigravity\scratch\Assignment5_AIChat\DotNet_Backend"

csproj_content = """<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Microsoft.AspNetCore.Authentication.JwtBearer" Version="8.0.0" />
    <PackageReference Include="Microsoft.EntityFrameworkCore.Design" Version="8.0.0">
      <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
      <PrivateAssets>all</PrivateAssets>
    </PackageReference>
    <PackageReference Include="Pomelo.EntityFrameworkCore.MySql" Version="8.0.0" />
  </ItemGroup>
</Project>"""

appsettings_json = """{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*",
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=AIChatDb;User=root;Password=;"
  },
  "Jwt": {
    "Key": "supersecretkeythatisverylongandsecure123!@#",
    "Issuer": "AIChatApp",
    "Audience": "AIChatUsers"
  }
}"""

program_cs = """using System.Text;
using DotNet_Backend.Data;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

// Add DbContext
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString)));

// Add Controllers
builder.Services.AddControllers();

// Configure CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        builder =>
        {
            builder.AllowAnyOrigin()
                   .AllowAnyMethod()
                   .AllowAnyHeader();
        });
});

// Configure JWT Auth
var jwtKey = builder.Configuration["Jwt:Key"];
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey))
        };
    });

var app = builder.Build();

app.UseCors("AllowAll");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.Run();"""

appdbcontext_cs = """using DotNet_Backend.Models;
using Microsoft.EntityFrameworkCore;

namespace DotNet_Backend.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<UserProfile> UserProfiles { get; set; }
}"""

userprofile_cs = """using System.ComponentModel.DataAnnotations;

namespace DotNet_Backend.Models;

public class UserProfile
{
    [Key]
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string Preferences { get; set; } = string.Empty;
}"""

authcontroller_cs = """using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using DotNet_Backend.Data;
using DotNet_Backend.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace DotNet_Backend.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly IConfiguration _configuration;

    public AuthController(AppDbContext context, IConfiguration configuration)
    {
        _context = context;
        _configuration = configuration;
    }

    public class LoginRequest { public string Username { get; set; } public string Password { get; set; } }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        // Simple mock authentication for assignment purposes
        var user = await _context.UserProfiles.FirstOrDefaultAsync(u => u.Username == request.Username);
        
        if (user == null) 
        {
            // Auto create for demo purposes
            user = new UserProfile { Username = request.Username, PasswordHash = "hash", DisplayName = request.Username, Preferences = "Dark Mode" };
            _context.UserProfiles.Add(user);
            await _context.SaveChangesAsync();
        }

        var tokenHandler = new JwtSecurityTokenHandler();
        var key = Encoding.ASCII.GetBytes(_configuration["Jwt:Key"]);
        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(new[] { 
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim("sub", user.Id.ToString()), // For FastAPI compatibility
                new Claim(ClaimTypes.Name, user.Username) 
            }),
            Expires = DateTime.UtcNow.AddDays(7),
            Issuer = _configuration["Jwt:Issuer"],
            Audience = _configuration["Jwt:Audience"],
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
        };
        var token = tokenHandler.CreateToken(tokenDescriptor);
        return Ok(new { token = tokenHandler.WriteToken(token) });
    }
}"""

profilecontroller_cs = """using System.Security.Claims;
using DotNet_Backend.Data;
using DotNet_Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DotNet_Backend.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class ProfileController : ControllerBase
{
    private readonly AppDbContext _context;

    public ProfileController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetProfile()
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
        var user = await _context.UserProfiles.FindAsync(userId);
        if (user == null) return NotFound();

        return Ok(new { user.DisplayName, user.Preferences });
    }

    public class UpdateProfileRequest { public string DisplayName { get; set; } public string Preferences { get; set; } }

    [HttpPut]
    public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileRequest request)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
        var user = await _context.UserProfiles.FindAsync(userId);
        if (user == null) return NotFound();

        user.DisplayName = request.DisplayName;
        user.Preferences = request.Preferences;
        await _context.SaveChangesAsync();

        return Ok(new { user.DisplayName, user.Preferences });
    }
}"""

create_file(f"{dotnet_dir}/DotNet_Backend.csproj", csproj_content)
create_file(f"{dotnet_dir}/appsettings.json", appsettings_json)
create_file(f"{dotnet_dir}/Program.cs", program_cs)
create_file(f"{dotnet_dir}/Data/AppDbContext.cs", appdbcontext_cs)
create_file(f"{dotnet_dir}/Models/UserProfile.cs", userprofile_cs)
create_file(f"{dotnet_dir}/Controllers/AuthController.cs", authcontroller_cs)
create_file(f"{dotnet_dir}/Controllers/ProfileController.cs", profilecontroller_cs)


# ==========================================
# 2. ANGULAR FRONTEND FILES
# ==========================================
ng_dir = r"C:\Users\sadul\.gemini\antigravity\scratch\Assignment5_AIChat\Angular_Frontend"

package_json = """{
  "name": "angular-frontend",
  "version": "0.0.0",
  "scripts": {
    "ng": "ng",
    "start": "ng serve",
    "build": "ng build",
    "watch": "ng build --watch --configuration development"
  },
  "private": true,
  "dependencies": {
    "@angular/animations": "^17.0.0",
    "@angular/common": "^17.0.0",
    "@angular/compiler": "^17.0.0",
    "@angular/core": "^17.0.0",
    "@angular/forms": "^17.0.0",
    "@angular/platform-browser": "^17.0.0",
    "@angular/platform-browser-dynamic": "^17.0.0",
    "@angular/router": "^17.0.0",
    "rxjs": "~7.8.0",
    "tslib": "^2.3.0",
    "zone.js": "~0.14.2"
  },
  "devDependencies": {
    "@angular-devkit/build-angular": "^17.0.0",
    "@angular/cli": "^17.0.0",
    "@angular/compiler-cli": "^17.0.0",
    "@types/node": "^18.18.0",
    "typescript": "~5.2.2"
  }
}"""

angular_json = """{
  "$schema": "./node_modules/@angular/cli/lib/config/schema.json",
  "version": 1,
  "newProjectRoot": "projects",
  "projects": {
    "angular-frontend": {
      "projectType": "application",
      "schematics": {},
      "root": "",
      "sourceRoot": "src",
      "prefix": "app",
      "architect": {
        "build": {
          "builder": "@angular-devkit/build-angular:browser",
          "options": {
            "outputPath": "dist/angular-frontend",
            "index": "src/index.html",
            "main": "src/main.ts",
            "polyfills": [
              "zone.js"
            ],
            "tsConfig": "tsconfig.app.json",
            "assets": [
              "src/favicon.ico",
              "src/assets"
            ],
            "styles": [
              "src/styles.css"
            ],
            "scripts": []
          }
        },
        "serve": {
          "builder": "@angular-devkit/build-angular:dev-server",
          "options": {
            "buildTarget": "angular-frontend:build"
          }
        }
      }
    }
  }
}"""

tsconfig_json = """{
  "compileOnSave": false,
  "compilerOptions": {
    "baseUrl": "./",
    "outDir": "./dist/out-tsc",
    "forceConsistentCasingInFileNames": true,
    "strict": true,
    "noImplicitOverride": true,
    "noPropertyAccessFromIndexSignature": true,
    "noImplicitReturns": true,
    "noFallthroughCasesInSwitch": true,
    "sourceMap": true,
    "declaration": false,
    "downlevelIteration": true,
    "experimentalDecorators": true,
    "moduleResolution": "node",
    "importHelpers": true,
    "target": "ES2022",
    "module": "ES2022",
    "useDefineForClassFields": false,
    "lib": [
      "ES2022",
      "dom"
    ]
  },
  "angularCompilerOptions": {
    "enableI18nLegacyMessageIdFormat": false,
    "strictInjectionParameters": true,
    "strictInputAccessModifiers": true,
    "strictTemplates": true
  }
}"""

tsconfig_app_json = """{
  "extends": "./tsconfig.json",
  "compilerOptions": {
    "outDir": "./out-tsc/app",
    "types": []
  },
  "files": [
    "src/main.ts"
  ],
  "include": [
    "src/**/*.d.ts"
  ]
}"""

src_index_html = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>AI Chat App</title>
  <base href="/">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="favicon.ico">
</head>
<body>
  <app-root></app-root>
</body>
</html>"""

src_main_ts = """import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';

bootstrapApplication(AppComponent, appConfig)
  .catch((err) => console.error(err));
"""

src_styles_css = """
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    padding: 0;
}
.container {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
}
"""

src_app_config_ts = """import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { authInterceptor } from './interceptors/auth.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(withInterceptors([authInterceptor]))
  ]
};"""

src_app_routes_ts = """import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { ChatComponent } from './components/chat/chat.component';
import { ProfileComponent } from './components/profile/profile.component';
import { authGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'chat', component: ChatComponent, canActivate: [authGuard] },
  { path: 'profile', component: ProfileComponent, canActivate: [authGuard] },
  { path: '', redirectTo: '/login', pathMatch: 'full' }
];"""

src_app_component_ts = """import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';
import { AuthService } from './services/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, CommonModule],
  template: `
    <nav *ngIf="authService.isLoggedIn()" style="background: #333; color: white; padding: 10px; display: flex; gap: 15px;">
        <a routerLink="/chat" style="color: white; text-decoration: none;">Chat</a>
        <a routerLink="/profile" style="color: white; text-decoration: none;">Profile</a>
        <button (click)="logout()" style="margin-left: auto;">Logout</button>
    </nav>
    <div class="container">
        <router-outlet></router-outlet>
    </div>
  `
})
export class AppComponent {
  constructor(public authService: AuthService) {}
  
  logout() {
    this.authService.logout();
  }
}"""

src_app_services_auth_ts = """import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private apiUrl = 'http://localhost:5000/api/auth'; // DotNet backend

  constructor(private http: HttpClient, private router: Router) {}

  login(credentials: any) {
    return this.http.post<{token: string}>(`${this.apiUrl}/login`, credentials).pipe(
      tap(res => {
        localStorage.setItem('token', res.token);
      })
    );
  }

  logout() {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }

  getToken() {
    return localStorage.getItem('token');
  }

  isLoggedIn() {
    return !!this.getToken();
  }
}"""

src_app_guards_auth_ts = """import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const authGuard = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (authService.isLoggedIn()) {
    return true;
  }

  return router.parseUrl('/login');
};"""

src_app_interceptors_auth_ts = """import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const token = authService.getToken();

  if (token) {
    const cloned = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
    return next(cloned);
  }

  return next(req);
};"""

src_app_components_login_ts = """import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  template: `
    <h2>Login</h2>
    <form [formGroup]="loginForm" (ngSubmit)="onSubmit()">
      <div style="margin-bottom: 10px;">
        <label>Username: </label>
        <input formControlName="username" type="text" />
      </div>
      <div style="margin-bottom: 10px;">
        <label>Password: </label>
        <input formControlName="password" type="password" />
      </div>
      <button type="submit" [disabled]="loginForm.invalid">Login</button>
    </form>
  `
})
export class LoginComponent {
  loginForm: FormGroup;

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.loginForm.valid) {
      this.authService.login(this.loginForm.value).subscribe({
        next: () => this.router.navigate(['/chat']),
        error: (err) => alert('Login failed')
      });
    }
  }
}"""

src_app_components_chat_ts = """import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  template: `
    <h2>AI Chat</h2>
    <button (click)="clearHistory()" style="margin-bottom: 10px;">Clear History</button>
    
    <div class="chat-box" #chatBox style="border: 1px solid #ccc; padding: 10px; height: 400px; overflow-y: scroll; margin-bottom: 10px; background: white;">
      <div *ngFor="let msg of messages" style="margin-bottom: 15px;">
        <strong [ngStyle]="{'color': msg.role === 'user' ? 'blue' : 'green'}">
          {{ msg.role === 'user' ? 'You' : 'AI' }}:
        </strong>
        <span style="white-space: pre-wrap;">{{ msg.content }}</span>
      </div>
      <div *ngIf="isTyping" style="font-style: italic; color: #888;">AI is typing...</div>
    </div>

    <form [formGroup]="chatForm" (ngSubmit)="sendMessage()" style="display: flex; gap: 10px;">
      <input formControlName="prompt" type="text" placeholder="Type your message..." style="flex: 1; padding: 10px;" />
      <button type="submit" [disabled]="chatForm.invalid || isStreaming" style="padding: 10px 20px;">Send</button>
    </form>
    <div *ngIf="errorMsg" style="color: red; margin-top: 10px;">{{ errorMsg }}</div>
  `
})
export class ChatComponent implements OnInit {
  chatForm: FormGroup;
  messages: any[] = [];
  sessionId = 'session_' + Math.floor(Math.random() * 1000000); // Simple session id
  isStreaming = false;
  isTyping = false;
  errorMsg = '';
  private fastapiUrl = 'http://localhost:8000'; // FastAPI backend

  @ViewChild('chatBox') private chatBoxContainer!: ElementRef;

  constructor(private fb: FormBuilder, private authService: AuthService, private http: HttpClient) {
    this.chatForm = this.fb.group({
      prompt: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.loadHistory();
  }

  scrollToBottom(): void {
    setTimeout(() => {
        try {
            this.chatBoxContainer.nativeElement.scrollTop = this.chatBoxContainer.nativeElement.scrollHeight;
        } catch(err) { }
    }, 100);
  }

  loadHistory() {
    this.http.get<any[]>(`${this.fastapiUrl}/history?session_id=${this.sessionId}`).subscribe({
      next: (data) => {
        this.messages = data;
        this.scrollToBottom();
      }
    });
  }

  clearHistory() {
    this.http.post(`${this.fastapiUrl}/clear`, { session_id: this.sessionId }).subscribe({
      next: () => {
        this.messages = [];
      }
    });
  }

  async sendMessage() {
    if (this.chatForm.invalid || this.isStreaming) return;

    const prompt = this.chatForm.value.prompt;
    this.messages.push({ role: 'user', content: prompt });
    this.chatForm.reset();
    this.isStreaming = true;
    this.isTyping = true;
    this.errorMsg = '';

    const aiMessageIndex = this.messages.push({ role: 'model', content: '' }) - 1;
    this.scrollToBottom();

    try {
      const token = this.authService.getToken();
      const response = await fetch(`${this.fastapiUrl}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ session_id: this.sessionId, prompt })
      });

      if (!response.ok) {
        if(response.status === 400) {
            const errorData = await response.json();
            throw new Error(errorData.detail || "Prompt injection detected.");
        }
        throw new Error('Failed to get response');
      }

      this.isTyping = false;
      const reader = response.body?.getReader();
      const decoder = new TextDecoder('utf-8');

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunk = decoder.decode(value, { stream: true });
          this.messages[aiMessageIndex].content += chunk;
          this.scrollToBottom();
        }
      }
    } catch (error: any) {
      this.errorMsg = error.message;
      this.messages.pop(); // remove empty ai message
    } finally {
      this.isStreaming = false;
      this.isTyping = false;
    }
  }
}"""

src_app_components_profile_ts = """import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  template: `
    <h2>User Profile</h2>
    <form [formGroup]="profileForm" (ngSubmit)="updateProfile()">
      <div style="margin-bottom: 10px;">
        <label>Display Name: </label>
        <input formControlName="displayName" type="text" />
      </div>
      <div style="margin-bottom: 10px;">
        <label>Preferences: </label>
        <input formControlName="preferences" type="text" />
      </div>
      <button type="submit" [disabled]="profileForm.invalid || isLoading">Save Changes</button>
    </form>
    <div *ngIf="successMsg" style="color: green; margin-top: 10px;">{{ successMsg }}</div>
  `
})
export class ProfileComponent implements OnInit {
  profileForm: FormGroup;
  isLoading = false;
  successMsg = '';
  private apiUrl = 'http://localhost:5000/api/profile'; // DotNet backend

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.profileForm = this.fb.group({
      displayName: ['', Validators.required],
      preferences: ['']
    });
  }

  ngOnInit() {
    this.http.get<any>(this.apiUrl).subscribe({
      next: (data) => {
        this.profileForm.patchValue(data);
      }
    });
  }

  updateProfile() {
    if (this.profileForm.valid) {
      this.isLoading = true;
      this.successMsg = '';
      this.http.put(this.apiUrl, this.profileForm.value).subscribe({
        next: () => {
          this.successMsg = 'Profile updated successfully!';
          this.isLoading = false;
        },
        error: () => {
          this.isLoading = false;
        }
      });
    }
  }
}"""


create_file(f"{ng_dir}/package.json", package_json)
create_file(f"{ng_dir}/angular.json", angular_json)
create_file(f"{ng_dir}/tsconfig.json", tsconfig_json)
create_file(f"{ng_dir}/tsconfig.app.json", tsconfig_app_json)
create_file(f"{ng_dir}/src/index.html", src_index_html)
create_file(f"{ng_dir}/src/main.ts", src_main_ts)
create_file(f"{ng_dir}/src/styles.css", src_styles_css)
create_file(f"{ng_dir}/src/app/app.config.ts", src_app_config_ts)
create_file(f"{ng_dir}/src/app/app.routes.ts", src_app_routes_ts)
create_file(f"{ng_dir}/src/app/app.component.ts", src_app_component_ts)

create_file(f"{ng_dir}/src/app/services/auth.service.ts", src_app_services_auth_ts)
create_file(f"{ng_dir}/src/app/guards/auth.guard.ts", src_app_guards_auth_ts)
create_file(f"{ng_dir}/src/app/interceptors/auth.interceptor.ts", src_app_interceptors_auth_ts)

create_file(f"{ng_dir}/src/app/components/login/login.component.ts", src_app_components_login_ts)
create_file(f"{ng_dir}/src/app/components/chat/chat.component.ts", src_app_components_chat_ts)
create_file(f"{ng_dir}/src/app/components/profile/profile.component.ts", src_app_components_profile_ts)

print("Generated all files successfully.")
