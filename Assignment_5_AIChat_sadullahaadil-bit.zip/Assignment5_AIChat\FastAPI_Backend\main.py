import os
import re
from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import google.generativeai as genai
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
from jose import jwt, JWTError

load_dotenv()

app = FastAPI(title="AI Chat API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # For development
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Config
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "supersecretkeythatisverylongandsecure123!@#")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")

# Setup Gemini
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-1.5-flash')

# Setup MongoDB
client = AsyncIOMotorClient(MONGO_URI)
db = client.aichatdb
history_collection = db.history

# JWT Auth Dependency
def get_current_user(request: Request):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid token")
    token = auth_header.split(" ")[1]
    try:
        payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
        return payload
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

class ChatRequest(BaseModel):
    session_id: str
    prompt: str

class ClearRequest(BaseModel):
    session_id: str

def check_prompt_injection(prompt: str) -> bool:
    # Basic prompt injection detection
    patterns = [
        r"ignore previous instructions",
        r"pretend you are",
        r"system prompt",
        r"forget everything",
        r"disregard"
    ]
    for pattern in patterns:
        if re.search(pattern, prompt, re.IGNORECASE):
            return True
    return False

@app.post("/chat")
async def chat(req: ChatRequest, user: dict = Depends(get_current_user)):
    if check_prompt_injection(req.prompt):
        raise HTTPException(status_code=400, detail="Prompt injection detected. Request rejected.")
    
    # Save user message to history
    await history_collection.insert_one({
        "session_id": req.session_id,
        "user_id": user.get("sub"),
        "role": "user",
        "content": req.prompt
    })

    # Retrieve previous history for context (optional, but good for real chat)
    cursor = history_collection.find({"session_id": req.session_id}).sort("_id", 1)
    history_docs = await cursor.to_list(length=20)
    
    messages = []
    for doc in history_docs[:-1]: # exclude the one we just added
        role = "user" if doc["role"] == "user" else "model"
        messages.append({"role": role, "parts": [doc["content"]]})
        
    messages.append({"role": "user", "parts": [req.prompt]})

    try:
        response = model.generate_content(messages, stream=True)
        
        async def stream_generator():
            full_response = ""
            for chunk in response:
                if chunk.text:
                    full_response += chunk.text
                    yield chunk.text
            
            # Save AI response to history after streaming completes
            await history_collection.insert_one({
                "session_id": req.session_id,
                "user_id": user.get("sub"),
                "role": "model",
                "content": full_response
            })
            
        return StreamingResponse(stream_generator(), media_type="text/plain")

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/history")
async def get_history(session_id: str, user: dict = Depends(get_current_user)):
    cursor = history_collection.find({"session_id": session_id})
    history_docs = await cursor.to_list(length=100)
    # Serialize for JSON
    for doc in history_docs:
        doc["_id"] = str(doc["_id"])
    return history_docs

@app.post("/clear")
async def clear_history(req: ClearRequest, user: dict = Depends(get_current_user)):
    result = await history_collection.delete_many({"session_id": req.session_id})
    return {"message": f"Cleared {result.deleted_count} messages."}
