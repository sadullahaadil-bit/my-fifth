﻿import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  template: 
    <h2>AI Chat</h2>
    <button (click)="clearHistory()" style="margin-bottom: 10px;">Clear History</button>
    
    <div class="chat-box" #chatBox style="border: 1px solid #ccc; padding: 10px; height: 400px; overflow-y: scroll; margin-bottom: 10px; background: white;">
      <div *ngFor="let msg of messages" style="margin-bottom: 15px;">
        <strong [ngStyle]="{'color': msg.role === 'user' ? 'blue' : 'green'}">
          {{ msg.role === 'user' ? 'You' : 'AI' }}:
        </strong>
        <span style="white-space: pre-wrap;">{{ msg.content }}</span>
      </div>
      <div *ngIf="isTyping" style="font-style: italic; color: #888;">AI is typing...</div>
    </div>

    <form [formGroup]="chatForm" (ngSubmit)="sendMessage()" style="display: flex; gap: 10px;">
      <input formControlName="prompt" type="text" placeholder="Type your message..." style="flex: 1; padding: 10px;" />
      <button type="submit" [disabled]="chatForm.invalid || isStreaming" style="padding: 10px 20px;">Send</button>
    </form>
    <div *ngIf="errorMsg" style="color: red; margin-top: 10px;">{{ errorMsg }}</div>
  
})
export class ChatComponent implements OnInit {
  chatForm: FormGroup;
  messages: any[] = [];
  sessionId = 'session_' + Math.floor(Math.random() * 1000000);
  isStreaming = false;
  isTyping = false;
  errorMsg = '';
  private fastapiUrl = 'http://localhost:8000';

  @ViewChild('chatBox') private chatBoxContainer!: ElementRef;

  constructor(private fb: FormBuilder, private authService: AuthService, private http: HttpClient) {
    this.chatForm = this.fb.group({
      prompt: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.loadHistory();
  }

  scrollToBottom(): void {
    setTimeout(() => {
        try {
            this.chatBoxContainer.nativeElement.scrollTop = this.chatBoxContainer.nativeElement.scrollHeight;
        } catch(err) { }
    }, 100);
  }

  loadHistory() {
    this.http.get<any[]>(${this.fastapiUrl}/history?session_id=).subscribe({
      next: (data) => {
        this.messages = data;
        this.scrollToBottom();
      }
    });
  }

  clearHistory() {
    this.http.post(${this.fastapiUrl}/clear, { session_id: this.sessionId }).subscribe({
      next: () => {
        this.messages = [];
      }
    });
  }

  async sendMessage() {
    if (this.chatForm.invalid || this.isStreaming) return;

    const prompt = this.chatForm.value.prompt;
    this.messages.push({ role: 'user', content: prompt });
    this.chatForm.reset();
    this.isStreaming = true;
    this.isTyping = true;
    this.errorMsg = '';

    const aiMessageIndex = this.messages.push({ role: 'model', content: '' }) - 1;
    this.scrollToBottom();

    try {
      const token = this.authService.getToken();
      const response = await fetch(${this.fastapiUrl}/chat, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': Bearer 
        },
        body: JSON.stringify({ session_id: this.sessionId, prompt })
      });

      if (!response.ok) {
        if(response.status === 400) {
            const errorData = await response.json();
            throw new Error(errorData.detail || "Prompt injection detected.");
        }
        throw new Error('Failed to get response');
      }

      this.isTyping = false;
      const reader = response.body?.getReader();
      const decoder = new TextDecoder('utf-8');

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunk = decoder.decode(value, { stream: true });
          this.messages[aiMessageIndex].content += chunk;
          this.scrollToBottom();
        }
      }
    } catch (error: any) {
      this.errorMsg = error.message;
      this.messages.pop();
    } finally {
      this.isStreaming = false;
      this.isTyping = false;
    }
  }
}
