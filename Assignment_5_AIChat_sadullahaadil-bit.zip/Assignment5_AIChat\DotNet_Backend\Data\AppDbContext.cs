﻿using DotNet_Backend.Models;
using Microsoft.EntityFrameworkCore;

namespace DotNet_Backend.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<UserProfile> UserProfiles { get; set; }
}
