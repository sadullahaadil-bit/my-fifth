﻿import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  template: 
    <h2>Login</h2>
    <form [formGroup]="loginForm" (ngSubmit)="onSubmit()">
      <div style="margin-bottom: 10px;">
        <label>Username: </label>
        <input formControlName="username" type="text" />
      </div>
      <div style="margin-bottom: 10px;">
        <label>Password: </label>
        <input formControlName="password" type="password" />
      </div>
      <button type="submit" [disabled]="loginForm.invalid">Login</button>
    </form>
  
})
export class LoginComponent {
  loginForm: FormGroup;

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.loginForm.valid) {
      this.authService.login(this.loginForm.value).subscribe({
        next: () => this.router.navigate(['/chat']),
        error: (err) => alert('Login failed')
      });
    }
  }
}
