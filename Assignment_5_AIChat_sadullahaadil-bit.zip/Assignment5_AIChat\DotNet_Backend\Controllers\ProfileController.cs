﻿using System.Security.Claims;
using DotNet_Backend.Data;
using DotNet_Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DotNet_Backend.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class ProfileController : ControllerBase
{
    private readonly AppDbContext _context;

    public ProfileController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetProfile()
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
        var user = await _context.UserProfiles.FindAsync(userId);
        if (user == null) return NotFound();

        return Ok(new { user.DisplayName, user.Preferences });
    }

    public class UpdateProfileRequest { public string DisplayName { get; set; } public string Preferences { get; set; } }

    [HttpPut]
    public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileRequest request)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
        var user = await _context.UserProfiles.FindAsync(userId);
        if (user == null) return NotFound();

        user.DisplayName = request.DisplayName;
        user.Preferences = request.Preferences;
        await _context.SaveChangesAsync();

        return Ok(new { user.DisplayName, user.Preferences });
    }
}
