﻿import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';
import { AuthService } from './services/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, CommonModule],
  template: 
    <nav *ngIf="authService.isLoggedIn()" style="background: #333; color: white; padding: 10px; display: flex; gap: 15px;">
        <a routerLink="/chat" style="color: white; text-decoration: none;">Chat</a>
        <a routerLink="/profile" style="color: white; text-decoration: none;">Profile</a>
        <button (click)="logout()" style="margin-left: auto;">Logout</button>
    </nav>
    <div class="container">
        <router-outlet></router-outlet>
    </div>
  
})
export class AppComponent {
  constructor(public authService: AuthService) {}
  
  logout() {
    this.authService.logout();
  }
}
