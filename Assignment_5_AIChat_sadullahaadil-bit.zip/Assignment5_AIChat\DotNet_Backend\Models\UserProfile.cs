﻿using System.ComponentModel.DataAnnotations;

namespace DotNet_Backend.Models;

public class UserProfile
{
    [Key]
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string Preferences { get; set; } = string.Empty;
}
